% for i=1:8
%     A{i}=xlsread('dsc jacob.xlsx',i);
% end

weights=[12.2180,12.8980,16.2530,15.4950,6.00800,10.7230,12.5940,11.1330];
close all
plot(0,0,'b', 'LineWidth', 2);
hold on
plot(0,0,'r', 'LineWidth', 2);
hold on


for i=1:length(A)
    if i<=3
        plot(A{i}(1:end-2,2),A{i}(1:end-2,3)/weights(i),'b', 'LineWidth', 2);
        hold on
    
    elseif i>=6
        plot(A{i}(1:end-2,2),A{i}(1:end-2,3)/weights(i),'r', 'LineWidth', 2);
        hold on
        
    end
end

    
    
    set(gca,'FontSize',14)
    xlabel(strcat('Temperature (', char(0176), 'C)'))
    ylabel('Heat Flow (W/g))')
    grid on
    xlim([0 150])
    ylim([-0.3 0])
    legend('dry','wet')