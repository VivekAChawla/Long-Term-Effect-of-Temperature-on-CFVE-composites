% clc
% clear all
% prompt='what is the length?'
% L=input(prompt);
% prompt='what is the strength?'
% tau=input(prompt);
% prompt='what is the radius?'
% radius=input(prompt);
% radius=1;
% 
% if length(radius)==1
%     radius=ones(length(tau),1)*radius;
% end


%% uncheck for new
% clc
% clear all
% 
% [~,sheets] = xlsfinfo('push out results_dry warp.xlsx');
% 
% prompt='what are the bad sheets'
% badsheets=input(prompt)

%%

for i=1:length(sheets)
   
    if ~ismember(i, badsheets)
        A{i}=readtable('push out results_dry warp.xlsx','Sheet',i);
        temp=table2array(A{i});
        Depth{i} =temp(:,end-2);
        Tau2{i} =temp(:,end);
    else
        Depth{i}=[];
        Tau2{i}=[];
    end
end


% sort everything

for i=1:length(Tau2)
    if ~ismember(i, badsheets)
        L=(Depth{i});
        tau=(Tau2{i});
        I=~isnan(L);
        temp_L=L(I); temp_tau=tau(I);
        I=~isnan(temp_tau);
        L=temp_L(I); tau=temp_tau(I);
    
    
z=1
m=1; shape =0; radius=1;
while z<=1000 & abs(m-shape)>=0.0001
if i==8
    dfas=123213;
end

multiplier=(radius.*L).^(1/m);
webtau=tau.*multiplier;
[web_tau_sorted,I]=sort(tau.*multiplier);
tau_sorted=tau(I);
L_sorted=L(I);
sample=1:length(L);


% weibull -tau
P=sample/length(L);
log_log_inverse_survival=(log(log(1./(1-P))))';
log_tau=log([web_tau_sorted]);
log_length=log(L_sorted);
[c,S]=polyfit(log_tau(1:end-1),log_log_inverse_survival(1:end-1),1)

shape=c(1);scale=exp(-c(2)/shape);

mdl = fitlm(log_tau(1:end-1),log_log_inverse_survival(1:end-1))

exp_cdf=-1*(web_tau_sorted./scale).^shape;

CDF=1-exp(exp_cdf);
PDF=(exp(-1*(web_tau_sorted/scale).^shape).*(shape).*(((web_tau_sorted/scale).^shape)))./web_tau_sorted;

z=z+1;
if abs(m-shape)<=0.1
    m
    shape
    m=shape;
    close all
    figure(1)
    scatter(web_tau_sorted,CDF)
    figure(2)
    scatter(web_tau_sorted,PDF)
    figure(3)
    scatter(log_tau(1:end-1),log_log_inverse_survival(1:end-1),'r')
    grid on
    xlim([0 8])
    ylim([ -7 1])
    
else
    
    m=shape;
    shape=100;
    
end
end

Cumul{i}=CDF;
Part{i}=PDF;
sorted_tau{i}=web_tau_sorted;
shape_1{i}=shape;
scale_1{i}=scale;
    else
        Cumul{i}=[];  
        Part{i}=[];
        sorted_tau{i}=[];
        shape_1{i}=[];
        scale_1{i}=[];
    end


end

1367
2458

close all
figure(1)
subplot(2,2,1)
scatter(0,0,'*k')
hold on
scatter(0,0,'*b')
hold on
scatter(0,0,'sb')
hold on
scatter(0,0,'db')
hold on
scatter(0,0,'*g')
hold on
scatter(0,0,'sg')
hold on
scatter(0,0,'dg')
hold on

scatter(0,0,'*r')
hold on
scatter(0,0,'sr')
hold on
scatter(0,0,'dr')
hold on



for i=1:3
scatter(sorted_tau{i},Cumul{i},'*k')
hold on
end

i=7
scatter(sorted_tau{i},Cumul{i},'*b')
hold on
i=17
scatter(sorted_tau{i},Cumul{i},'sb')
hold on
i=19
scatter(sorted_tau{i},Cumul{i},'db')
hold on


i=9
scatter(sorted_tau{i},Cumul{i},'*g')
hold on
i=15
scatter(sorted_tau{i},Cumul{i},'sg')
hold on
i=21
scatter(sorted_tau{i},Cumul{i},'dg')
hold on


i=11
scatter(sorted_tau{i},Cumul{i},'*r')
hold on
i=13
scatter(sorted_tau{i},Cumul{i},'sr')
hold on
i=23
scatter(sorted_tau{i},Cumul{i},'dr')
hold on

% i=3;
% scatter(sorted_tau{i},Cumul{i},'*r')
% hold on

% i=6;
% scatter(sorted_tau{i},Cumul{i},'sb')
% hold on
% i=7;
% scatter(sorted_tau{i},Cumul{i},'sr')
% hold on
xlabel('Ln (\tau V^1^/^m)')
ylabel('Cumilative Probability')
title('Cumilitive Distribution Function (Warp)')
set(gca,'FontSize',14)
% legend('Unconditioned',strcat('-80', char(0176), 'C 1 Year'),strcat('-80', char(0176), 'C 6 Months'),strcat('-80', char(0176), 'C 1 Month'),'Cyclic 1 Year','Cyclic 6 Months','Cyclic 1 Month',strcat('+80', char(0176), 'C 1 Year'),strcat('+80', char(0176), 'C 6 Months'),strcat('+80', char(0176), 'C 1 Month'))



subplot(2,2,2)
scatter(0,0,'*k')
hold on
scatter(0,0,'*b')
hold on
scatter(0,0,'sb')
hold on
scatter(0,0,'db')
hold on
scatter(0,0,'*g')
hold on
scatter(0,0,'sg')
hold on
scatter(0,0,'dg')
hold on
scatter(0,0,'*r')
hold on
scatter(0,0,'sr')
hold on
scatter(0,0,'dr')
hold on

for i=1:3
scatter(sorted_tau{i},Part{i},'*k')
hold on
end

i=7
scatter(sorted_tau{i},Part{i},'*b')
hold on
i=17
scatter(sorted_tau{i},Part{i},'sb')
hold on
i=19
scatter(sorted_tau{i},Part{i},'db')
hold on


i=9
scatter(sorted_tau{i},Part{i},'*g')
hold on
i=15
scatter(sorted_tau{i},Part{i},'sg')
hold on
i=21
scatter(sorted_tau{i},Part{i},'dg')
hold on


i=11
scatter(sorted_tau{i},Part{i},'*r')
hold on
i=13
scatter(sorted_tau{i},Part{i},'sr')
hold on
i=23
scatter(sorted_tau{i},Part{i},'dr')
hold on



% i=1;
% scatter(sorted_tau{i},Part{i},'*b')
% hold on
% i=3;
% scatter(sorted_tau{i},Part{i},'*r')
% hold on
% i=6;
% scatter(sorted_tau{i},Part{i},'sb')
% hold on
% i=7;
% scatter(sorted_tau{i},Part{i},'sr')
% hold on
xlabel('Ln (\tau V^1^/^m)')
ylabel('Probability ')
title('Probability Density Function (Warp)')
set(gca,'FontSize',14)
legend('Dry',strcat('-80', char(0176), 'C 1 Year'),strcat('-80', char(0176), 'C 6 Months'),strcat('-80', char(0176), 'C 1 Month'),'Cyclic 1 Year','Cyclic 6 Months','Cyclic 1 Month',strcat('+80', char(0176), 'C 1 Year'),strcat('+80', char(0176), 'C 6 Months'),strcat('+80', char(0176), 'C 1 Month'))


subplot(2,2,3)
scatter(0,0,'*k')
hold on
scatter(0,0,'*b')
hold on
scatter(0,0,'sb')
hold on
scatter(0,0,'db')
hold on
scatter(0,0,'*g')
hold on
scatter(0,0,'sg')
hold on
scatter(0,0,'dg')
hold on

scatter(0,0,'*r')
hold on
scatter(0,0,'sr')
hold on
scatter(0,0,'dr')
hold on



for i=4:6
scatter(sorted_tau{i},Cumul{i},'*k')
hold on
end

i=8
scatter(sorted_tau{i},Cumul{i},'*b')
hold on
i=14
scatter(sorted_tau{i},Cumul{i},'sb')
hold on
i=20
scatter(sorted_tau{i},Cumul{i},'db')
hold on


i=10
scatter(sorted_tau{i},Cumul{i},'*g')
hold on
i=18
scatter(sorted_tau{i},Cumul{i},'sg')
hold on
i=22
scatter(sorted_tau{i},Cumul{i},'dg')
hold on


i=12
scatter(sorted_tau{i},Cumul{i},'*r')
hold on
i=16
scatter(sorted_tau{i},Cumul{i},'sr')
hold on
i=24
scatter(sorted_tau{i},Cumul{i},'dr')
hold on

% i=3;
% scatter(sorted_tau{i},Cumul{i},'*r')
% hold on

% i=6;
% scatter(sorted_tau{i},Cumul{i},'sb')
% hold on
% i=7;
% scatter(sorted_tau{i},Cumul{i},'sr')
% hold on
xlabel('Ln (\tau V^1^/^m)')
xlim([0 500])
ylabel('Cumilative Probability')
title('Cumilitive Distribution Function (Fill)')
set(gca,'FontSize',14)
% legend('Unconditioned',strcat('-80', char(0176), 'C 1 Year'),strcat('-80', char(0176), 'C 6 Months'),strcat('-80', char(0176), 'C 1 Month'),'Cyclic 1 Year','Cyclic 6 Months','Cyclic 1 Month',strcat('+80', char(0176), 'C 1 Year'),strcat('+80', char(0176), 'C 6 Months'),strcat('+80', char(0176), 'C 1 Month'))




subplot(2,2,4)


scatter(0,0,'*k')
hold on
scatter(0,0,'*b')
hold on
scatter(0,0,'sb')
hold on
scatter(0,0,'db')
hold on
scatter(0,0,'*g')
hold on
scatter(0,0,'sg')
hold on
scatter(0,0,'dg')
hold on
scatter(0,0,'*r')
hold on
scatter(0,0,'sr')
hold on
scatter(0,0,'dr')
hold on

for i=4:6
scatter(sorted_tau{i},Part{i},'*k')
hold on
end

i=8
scatter(sorted_tau{i},Part{i},'*b')
hold on
i=14
scatter(sorted_tau{i},Part{i},'sb')
hold on
i=20
scatter(sorted_tau{i},Part{i},'db')
hold on


i=10
scatter(sorted_tau{i},Part{i},'*g')
hold on
i=18
scatter(sorted_tau{i},Part{i},'sg')
hold on
i=22
scatter(sorted_tau{i},Part{i},'dg')
hold on


i=12
scatter(sorted_tau{i},Part{i},'*r')
hold on
i=16
scatter(sorted_tau{i},Part{i},'sr')
hold on
i=24
scatter(sorted_tau{i},Part{i},'dr')
hold on


xlabel('Ln (\tau V^1^/^m)')
xlim([0 500])
ylabel('Probability ')
title('Probability Density Function (Fill)')
set(gca,'FontSize',14)
legend('Dry',strcat('-80', char(0176), 'C 1 Year'),strcat('-80', char(0176), 'C 6 Months'),strcat('-80', char(0176), 'C 1 Month'),'Cyclic 1 Year','Cyclic 6 Months','Cyclic 1 Month',strcat('+80', char(0176), 'C 1 Year'),strcat('+80', char(0176), 'C 6 Months'),strcat('+80', char(0176), 'C 1 Month'))


