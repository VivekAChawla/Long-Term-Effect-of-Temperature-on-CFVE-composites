%%PCA
close all
clc
clear all


%% NC
i=1
NC_2006_dry{i}=readmatrix('06dry resin_NC_1.csv');
temp(:,i)=NC_2006_dry{i}(:,2);
baddry=[4, 6, 10];
z=2;
for i=2:10
filename=strcat('06dry resin_NC00',num2str(i-1),'_1.csv');
NC_2006_dry{i}=readmatrix(filename);
if ~ismember(i, baddry)
temp(:,z)=NC_2006_dry{i}(:,2);
z=z+1;
end

end
% NC_2006_dry{4}=[];NC_2006_dry{6}=[];NC_2006_dry{10}=[];
baddry=[4, 6, 10];
figure(1)
for i=1:10
    if ~ismember(i, baddry)
    % x=[];y=[];
    % x=NC_2006_dry{i}(:,1);y=NC_2006_dry{i}(:,2); 
    % order=2;
    % yout=detrend(NC_2006_dry{i},order);
    plot(NC_2006_dry{i}(:,1),NC_2006_dry{i}(:,2),'LineWidth',2)
    hold on
    end
end
figure(2)
Avg_NC_2006_dry=[NC_2006_dry{1}(:,1), mean(temp,2)];
plot(Avg_NC_2006_dry(:,1),Avg_NC_2006_dry(:,2)/max(Avg_NC_2006_dry(:,2)),'k','LineWidth',2)
hold on


i=1
z=2;
badwet=[2,3,4,5,7,9,10];
NC_2006_wet{i}=readmatrix('06wet resin_NC_1.csv');
temp=[];temp(:,i)=NC_2006_wet{i}(:,2);
for i=2:10
filename=strcat('06wet resin_NC00',num2str(i-1),'_1.csv');
NC_2006_wet{i}=readmatrix(filename);
if ~ismember(i, badwet)
temp(:,z)=NC_2006_wet{i}(:,2);
z=z+1;
end
end

figure(1)
for i=1:10
    if ~ismember(i, badwet)
    plot(NC_2006_wet{i}(:,1),NC_2006_wet{i}(:,2),'LineWidth',2)
    hold on
    end

end
figure(2)
hold on
Avg_NC_2006_wet=[NC_2006_wet{1}(:,1), mean(temp,2)];
plot(Avg_NC_2006_wet(:,1),Avg_NC_2006_wet(:,2)/max(Avg_NC_2006_wet(:,2)),':k','LineWidth',2)
hold on



i=1
NC_2012_dry{i}=readmatrix('12DryNC000_1.csv');
temp=[];temp(:,i)=NC_2012_dry{i}(:,2);
for i=2:10
filename=strcat('12DryNC00',num2str(i-1),'_1.csv');
NC_2012_dry{i}=readmatrix(filename);
temp(:,i)=NC_2012_dry{i}(:,2);
end
% figure(1)
% for i=1:10
%     plot(NC_2012_dry{i}(:,1),NC_2012_dry{i}(:,2),'g','LineWidth',2)
%     hold on
% end
% figure(2)
% hold on
% Avg_NC_2012_dry=[NC_2012_dry{1}(:,1), mean(temp,2)];
% plot(Avg_NC_2012_dry(:,1),Avg_NC_2012_dry(:,2),'g','LineWidth',2)
% hold on



i=1
NC_2012_wet{i}=readmatrix('12wetNC_1.csv');
temp=[];temp(:,i)=NC_2012_dry{i}(:,2);

for i=2:10
filename=strcat('12wetNC00',num2str(i-1),'_1.csv');
NC_2012_wet{i}=readmatrix(filename);
temp(:,i)=NC_2012_wet{i}(:,2);
end
% figure(1)
% for i=1:10
%     plot(NC_2012_wet{i}(:,1),NC_2012_wet{i}(:,2),'c','LineWidth',2)
%     hold on
% end
% figure(2)
% hold on
% Avg_NC_2012_wet=[NC_2012_wet{1}(:,1), mean(temp,2)];
% plot(Avg_NC_2012_wet(:,1),Avg_NC_2012_wet(:,2),'c','LineWidth',2)
% hold on

%% neg 80
i=1
nega_2006_dry{i}=readmatrix('06Dry_nega80_1.csv');
temp(:,i)=nega_2006_dry{i}(:,2);
for i=2:10
filename=strcat('06Dry_nega8000',num2str(i-1),'_1.csv');
nega_2006_dry{i}=readmatrix(filename);
temp(:,i)=nega_2006_dry{i}(:,2);
end
figure(1)
for i=1:10
    plot(nega_2006_dry{i}(:,1),nega_2006_dry{i}(:,2),':b','LineWidth',2)
    hold on
end
figure(2)
Avg_nega_2006_dry=[nega_2006_dry{1}(:,1), mean(temp,2)];
plot(Avg_nega_2006_dry(:,1),Avg_nega_2006_dry(:,2)/max(Avg_nega_2006_dry(:,2)),'b','LineWidth',2)
hold on


i=1
nega_2006_wet{i}=readmatrix('06Wet_nega80_1.csv');
temp=[];temp(:,i)=nega_2006_wet{i}(:,2);
for i=2:10
filename=strcat('06Wet_nega8000',num2str(i-1),'_1.csv');
nega_2006_wet{i}=readmatrix(filename);
temp(:,i)=nega_2006_wet{i}(:,2);
end
figure(1)
for i=1:10
    plot(nega_2006_wet{i}(:,1),nega_2006_wet{i}(:,2),':r','LineWidth',2)
    hold on
end
figure(2)
hold on
Avg_nega_2006_wet=[nega_2006_wet{1}(:,1), mean(temp,2)];
plot(Avg_nega_2006_wet(:,1),Avg_nega_2006_wet(:,2)/max(Avg_nega_2006_wet(:,2)),':b','LineWidth',2)
hold on



i=1
nega_2012_dry{i}=readmatrix('12Dry_nega80_1.csv');
temp=[];temp(:,i)=nega_2012_dry{i}(:,2);
for i=2:10
filename=strcat('12Dry_nega8000',num2str(i-1),'_1.csv');
nega_2012_dry{i}=readmatrix(filename);
temp(:,i)=nega_2012_dry{i}(:,2);
end
% figure(1)
% for i=1:10
%     plot(nega_2012_dry{i}(:,1),nega_2012_dry{i}(:,2),':g','LineWidth',2)
%     hold on
% end
% figure(2)
% hold on
% Avg_nega_2012_dry=[nega_2012_dry{1}(:,1), mean(temp,2)];
% plot(Avg_nega_2012_dry(:,1),Avg_nega_2012_dry(:,2),':g','LineWidth',2)
% hold on



i=1
nega_2012_wet{i}=readmatrix('12Wet_nega80_1.csv');
temp=[];temp(:,i)=nega_2012_dry{i}(:,2);

for i=2:10
filename=strcat('12Wet_nega8000',num2str(i-1),'_1.csv');
nega_2012_wet{i}=readmatrix(filename);
temp(:,i)=nega_2012_wet{i}(:,2);
end
% figure(1)
% for i=1:10
%     plot(nega_2012_wet{i}(:,1),nega_2012_wet{i}(:,2),':c','LineWidth',2)
%     hold on
% end
% figure(2)
% hold on
% Avg_nega_2012_wet=[nega_2012_wet{1}(:,1), mean(temp,2)];
% plot(Avg_nega_2012_wet(:,1),Avg_nega_2012_wet(:,2),':c','LineWidth',2)
% hold on



%% Cyclic
i=1
cyclic_2006_dry{i}=readmatrix('06 dry resin_cyclic_1.csv');
temp(:,i)=cyclic_2006_dry{i}(:,2);
for i=2:10
filename=strcat('06 dry resin_cyclic00',num2str(i-1),'_1.csv');
cyclic_2006_dry{i}=readmatrix(filename);
temp(:,i)=cyclic_2006_dry{i}(:,2);
end
figure(1)
for i=1:10
    plot(cyclic_2006_dry{i}(:,1),cyclic_2006_dry{i}(:,2),'--b','LineWidth',2)
    hold on
end
figure(2)
Avg_cyclic_2006_dry=[cyclic_2006_dry{1}(:,1), mean(temp,2)];
plot(Avg_cyclic_2006_dry(:,1),Avg_cyclic_2006_dry(:,2)/max(Avg_cyclic_2006_dry(:,2)),'g','LineWidth',2)
hold on


i=1
cyclic_2006_wet{i}=readmatrix('06 wet resin_cyclic_1.csv');
temp=[];temp(:,i)=cyclic_2006_wet{i}(:,2);
for i=2:10
filename=strcat('06 wet resin_cyclic00',num2str(i-1),'_1.csv');
cyclic_2006_wet{i}=readmatrix(filename);
temp(:,i)=cyclic_2006_wet{i}(:,2);
end
figure(1)
for i=1:10
    plot(cyclic_2006_wet{i}(:,1),cyclic_2006_wet{i}(:,2),'--r','LineWidth',2)
    hold on
end
figure(2)
hold on
Avg_cyclic_2006_wet=[cyclic_2006_wet{1}(:,1), mean(temp,2)];
plot(Avg_cyclic_2006_wet(:,1),Avg_cyclic_2006_wet(:,2)/max(Avg_cyclic_2006_wet(:,2)),':g','LineWidth',2)
hold on



i=1
cyclic_2012_dry{i}=readmatrix('12dry resin_cyclic_1.csv');
temp=[];temp(:,i)=cyclic_2012_dry{i}(:,2);
for i=2:10
filename=strcat('12dry resin_cyclic00',num2str(i-1),'_1.csv');
cyclic_2012_dry{i}=readmatrix(filename);
temp(:,i)=cyclic_2012_dry{i}(:,2);
end
% figure(1)
% for i=1:10
%     plot(cyclic_2012_dry{i}(:,1),cyclic_2012_dry{i}(:,2),'--g','LineWidth',2)
%     hold on
% end
% figure(2)
% hold on
% Avg_cyclic_2012_dry=[cyclic_2012_dry{1}(:,1), mean(temp,2)];
% plot(Avg_cyclic_2012_dry(:,1),Avg_cyclic_2012_dry(:,2),'--g','LineWidth',2)
% hold on



i=1
cyclic_2012_wet{i}=readmatrix('12wet resin_cyclic_1.csv');
temp=[];temp(:,i)=cyclic_2012_dry{i}(:,2);

for i=2:10
filename=strcat('12wet resin_cyclic00',num2str(i-1),'_1.csv');
cyclic_2012_wet{i}=readmatrix(filename);
temp(:,i)=cyclic_2012_wet{i}(:,2);
end
% figure(1)
% for i=1:10
%     plot(cyclic_2012_wet{i}(:,1),cyclic_2012_wet{i}(:,2),'--c','LineWidth',2)
%     hold on
% end
% figure(2)
% hold on
% Avg_cyclic_2012_wet=[cyclic_2012_wet{1}(:,1), mean(temp,2)];
% plot(Avg_cyclic_2012_wet(:,1),Avg_cyclic_2012_wet(:,2),'--c','LineWidth',2)
% hold on









%% 80
i=1
neg_80_2006_dry{i}=readmatrix('06dry resin_neg80_1.csv');
temp(:,i)=neg_80_2006_dry{i}(:,2);
for i=2:10
filename=strcat('06 dry resin_neg8000',num2str(i-1),'_1.csv');
neg_80_2006_dry{i}=readmatrix(filename);
temp(:,i)=neg_80_2006_dry{i}(:,2);
end
figure(1)
for i=1:10
    plot(neg_80_2006_dry{i}(:,1),neg_80_2006_dry{i}(:,2),'-.b','LineWidth',2)
    hold on
end
figure(2)
Avg_neg_80_2006_dry=[neg_80_2006_dry{1}(:,1), mean(temp,2)];
plot(Avg_neg_80_2006_dry(:,1),Avg_neg_80_2006_dry(:,2)/max(Avg_neg_80_2006_dry(:,2)),'r','LineWidth',2)
hold on





i=1
neg_80_2006_wet{i}=readmatrix('06 wet resin_neg80_1.csv');
temp=[];temp(:,i)=neg_80_2006_wet{i}(:,2);
for i=2:10
filename=strcat('06 wet resin_neg8000',num2str(i-1),'_1.csv');
neg_80_2006_wet{i}=readmatrix(filename);
temp(:,i)=neg_80_2006_wet{i}(:,2);
end

figure(1)
for i=1:10
    plot(neg_80_2006_wet{i}(:,1),neg_80_2006_wet{i}(:,2),'-.r','LineWidth',2)
    hold on
end

figure(2)
hold on
Avg_neg_80_2006_wet=[neg_80_2006_wet{1}(:,1), mean(temp,2)];
plot(Avg_neg_80_2006_wet(:,1),Avg_neg_80_2006_wet(:,2)/max(Avg_neg_80_2006_wet(:,2)),':r','LineWidth',2)
hold on



i=1
neg_80_2012_dry{i}=readmatrix('12 Dry resin_a_neg80_1.csv');
temp=[];temp(:,i)=neg_80_2012_dry{i}(:,2);
for i=2:7
filename=strcat('12 dry resin_neg80_a00',num2str(i-1),'_1.csv');
neg_80_2012_dry{i}=readmatrix(filename);
temp(:,i)=neg_80_2012_dry{i}(:,2);
end
% figure(1)
% for i=1:7
%     plot(neg_80_2012_dry{i}(:,1),neg_80_2012_dry{i}(:,2),'-.g','LineWidth',2)
%     hold on
% end
% figure(2)
% hold on
% Avg_neg_80_2012_dry=[neg_80_2012_dry{1}(:,1), mean(temp,2)];
% plot(Avg_neg_80_2012_dry(:,1),Avg_neg_80_2012_dry(:,2),'-.g','LineWidth',2)
% hold on



for i=1:8
filename=strcat('12 wet resin_neg80003_1 (',num2str(i),').csv');
neg_80_2012_wet{i}=readmatrix(filename);
temp(:,i)=neg_80_2012_wet{i}(:,2);
end
% figure(1)
% for i=1:8
%     plot(neg_80_2012_wet{i}(:,1),neg_80_2012_wet{i}(:,2),'-.c','LineWidth',2)
%     hold on
% end
% figure(2)
% hold on
% Avg_neg_80_2012_wet=[neg_80_2012_wet{1}(:,1), mean(temp,2)];
% plot(Avg_neg_80_2012_wet(:,1),Avg_neg_80_2012_wet(:,2),'-.c','LineWidth',2)
% hold on


figure(2)
set(gca,'FontSize',14)
xlabel('Wavenumber cm^-^1')
ylabel('Absorbance')
grid on
xlim([500 4000])
ylim([-0.05 1])
legend('Dry aged 15 Years','Wet aged 15 Years','Dry aged 15 Years & 1 Year at -80C','Wet aged 15 Years & 1 Year at -80C','Dry aged 15 Years & 1 Year Cyclic Conditioning','Wet aged 15 Years & 1 Year Cyclic Conditioning','Dry aged 15 Years & 1 Year at 80C','Wet aged 15 Years & 1 Year at 80C')


%%
% close all
i=1
A=[];
for i=1:10
    % if ~ismember(i, baddry) 
 A=[A;NC_2006_dry{i}(:,2)'/max(NC_2006_dry{i}(:,2))];
    % else
    %     A=[A;A(1,:)];
    % end
end
for i=1:10
 %    if ~ismember(i, badwet) 
 A=[A;NC_2006_wet{i}(:,2)'/max(NC_2006_wet{i}(:,2))];
 %    else
 %        A=[A;A(11,:)];
 %    end
end 

for i=1:10
 A=[A;nega_2006_dry{i}(:,2)'/max(nega_2006_dry{i}(:,2))];
end
for i=1:10
 A=[A;nega_2006_wet{i}(:,2)'/max(nega_2006_wet{i}(:,2))];
end 

for i=1:10
 A=[A;cyclic_2006_dry{i}(:,2)'/max(cyclic_2006_dry{i}(:,2))];
end
for i=1:10
 A=[A;cyclic_2006_wet{i}(:,2)'/max(cyclic_2006_wet{i}(:,2))];
end 

for i=1:10
 A=[A;neg_80_2006_dry{i}(:,2)'/max(neg_80_2006_dry{i}(:,2))];
end
for i=1:10
 A=[A;neg_80_2006_wet{i}(:,2)'/max(neg_80_2006_wet{i}(:,2))];
end 



[coeff,score,latent,tsquared,explained,mu1]=pca(A);

 figure(3)
for i=1
scatter(score(i,1),score(i,2),101,'*k')
hold on
end
for i=11
scatter(score(i,1),score(i,2),101,'ok')
hold on
end
for i=21
scatter(score(i,1),score(i,2),101,'*b')
hold on
end
for i=31
scatter(score(i,1),score(i,2),101,'ob')
hold on
end
for i=41
scatter(score(i,1),score(i,2),101,'*g')
hold on
end
for i=51
scatter(score(i,1),score(i,2),101,'og')
hold on
end
for i=61
scatter(score(i,1),score(i,2),101,'*r')
hold on
end
for i=71
scatter(score(i,1),score(i,2),101,'or')
hold on
end



for i=2:10
scatter(score(i,1),score(i,2),101,'*k')
hold on
end
for i=12:20
scatter(score(i,1),score(i,2),101,'ok')
hold on
end
for i=22:30
scatter(score(i,1),score(i,2),101,'*b')
hold on
end
for i=32:40
scatter(score(i,1),score(i,2),101,'ob')
hold on
end
for i=42:50
scatter(score(i,1),score(i,2),101,'*g')
hold on
end
for i=52:60
scatter(score(i,1),score(i,2),101,'og')
hold on
end
for i=62:70
scatter(score(i,1),score(i,2),101,'*r')
hold on
end
for i=72:80
scatter(score(i,1),score(i,2),101,'or')
hold on
end



set(gca,'FontSize',24)
xlabel('PC1')
ylabel('PC2')
grid on

legend('Dry aged 15 Years','Wet aged 15 Years','Dry aged 15 Years & 1 Year at -80C','Wet aged 15 Years & 1 Year at -80C','Dry aged 15 Years & 1 Year Cyclic Conditioning','Wet aged 15 Years & 1 Year Cyclic Conditioning','Dry aged 15 Years & 1 Year at 80C','Wet aged 15 Years & 1 Year at 80C')



% 
% 
% 
% 
% 
% 
% i=1
% A=[neg_80_2006_dry{i}(:,2)'];
% for i=2:10
%  A=[A;neg_80_2006_dry{i}(:,2)'];
% end
% for i=1:10
%  A=[A;neg_80_2006_wet{i}(:,2)'];
% end 
% for i=1:7
%  A=[A;neg_80_2012_dry{i}(:,2)'];
% end 
% for i=1:8
%  A=[A;neg_80_2012_wet{i}(:,2)'];
% end
% 
% 
% for i=1:10
%  A=[A;cyclic_2006_dry{i}(:,2)'];
% end
% for i=1:10
%  A=[A;cyclic_2006_wet{i}(:,2)'];
% end 
% for i=1:10
%  A=[A;cyclic_2012_dry{i}(:,2)'];
% end 
% for i=1:10
%  A=[A;cyclic_2012_wet{i}(:,2)'];
% end
% 
% for i=1:10
%  A=[A;nega_2006_dry{i}(:,2)'];
% end
% for i=1:10
%  A=[A;nega_2006_wet{i}(:,2)'];
% end 
% for i=1:10
%  A=[A;nega_2012_dry{i}(:,2)'];
% end 
% for i=1:10
%  A=[A;nega_2012_wet{i}(:,2)'];
% end
% 
% 
% 
% for i=1:10
%  A=[A;NC_2006_dry{i}(:,2)'];
% end
% for i=1:10
%  A=[A;NC_2006_wet{i}(:,2)'];
% end 
% for i=1:10
%  A=[A;NC_2012_dry{i}(:,2)'];
% end 
% for i=1:10
%  A=[A;NC_2012_wet{i}(:,2)'];
% end
% 
% 
% %%
% 
% [coeff,score1,latent,N,N,explained]=pca(A);
% 
%  figure(3)
% for i=1:10
% scatter(score1(i,2),score1(i,3),'*b')
% hold on
% end
% for i=11:20
% scatter(score1(i,2),score1(i,3),'*r')
% hold on
% end
% % for i=22:28
% % scatter(score1(i,2),score1(i,3),'*g')
% % hold on
% % end
% % for i=29:36
% % scatter(score1(i,2),score1(i,3),'*y')
% % hold on
% % end
% 
% 
% for i=37:46
% scatter(score1(i,2),score1(i,3),'oc')
% hold on
% end
% for i=47:56
% scatter(score1(i,2),score1(i,3),'om')
% hold on
% end
% % for i=57:66
% % scatter(score1(i,2),score1(i,3),'ok')
% % hold on
% % end
% % for i=67:76
% % scatter(score1(i,2),score1(i,3),'ob')
% % hold on
% % end
% 
% 
% for i=77:86
% scatter(score1(i,2),score1(i,3),'sc')
% hold on
% end
% for i=87:96
% scatter(score1(i,2),score1(i,3),'sm')
% hold on
% end
% % for i=97:106
% % scatter(score1(i,2),score1(i,3),'sk')
% % hold on
% % end
% % for i=107:116
% % scatter(score1(i,2),score1(i,3),'sb')
% % hold on
% % end
% 
% 
% 
% for i=117:126
% scatter(score1(i,2),score1(i,3),'dc')
% hold on
% end
% for i=127:136
% scatter(score1(i,2),score1(i,3),'dm')
% hold on
% end
% % for i=137:146
% % scatter(score1(i,2),score1(i,3),'dk')
% % hold on
% % end
% % for i=147:156
% % scatter(score1(i,2),score1(i,3),'db')
% % hold on
% % end

%%
% figure(2)
% set(gca,'FontSize',14)
% xlabel('Wavenumber cm^-^1')
% ylabel('Absorbance')
% grid on
% xlim([500 4000])
% ylim([-0.05 0.3])
% legend('Dry aged 15 Years','Wet aged 15 Years','Dry aged 15 Years & 1 Year at 80C','Wet aged 15 Years & 1 Year at 80C','Dry aged 15 Years & 1 Year Cyclic Conditioning','Wet aged 15 Years & 1 Year Cyclic Conditioning','Dry aged 15 Years & 1 Year at -80C','Wet aged 15 Years & 1 Year at -80C')